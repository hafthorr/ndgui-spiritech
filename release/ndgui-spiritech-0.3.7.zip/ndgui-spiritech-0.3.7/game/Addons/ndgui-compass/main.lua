-- Dovvetech prk.compass: DarkTech heading strip from ndgui-lib package PNGs (no atlas).
-- Band / waypoint / caret are BitmapViews scrolled with ui.place. Stock PannedSurface
-- path remains only as an emergency fallback if the package views cannot be bound.
ui.require("notum.ndgui-lib/grid")
local D = ui.require("notum.ndgui-lib/dovvetech")
local root = ui.load("window.xml")
ui.root(root)
local placement = D.movable(root)

local function try_find(name)
	local ok, view = pcall(ui.find, root, name)
	return ok and view or nil
end

local pkg = try_find("compass_pkg")
local band_a = try_find("pkg_band_a")
local band_b = try_find("pkg_band_b")
local pkg_waypoint = try_find("pkg_waypoint")
local pkg_caret = try_find("pkg_caret")
local box = ui.find(root, "compass_box")
local band = ui.find(root, "compass_band")
local back = ui.find(root, "ndgui_compass_back")
local frame = ui.find(root, "ndgui_compass_frame")
local label = ui.find(root, "compass_label")
local distance = ui.find(root, "compass_distance")
local distance_shadow = ui.find(root, "compass_distance_shadow")

local STOCK = { band = "GFX_GUI_COMPASS_SCALE", waypoint = "GFX_GUI_COMPASS_WAYPOINT" }
local VIEW_W, BAND_H, LABEL_H = 320, 54, 14
local BAND_PNG_W, BAND_PNG_H = 1080, 34
local WAYPOINT_W, WAYPOINT_H = 23, 29
local CARET_W, CARET_H = 15, 9
local LINE_Y, MARKER_Y, CARET_Y = 27, 14, 48
local EDGE = 14
local turn = math.pi * 2
local use_pkg, band_width, view_width, view_height = true, BAND_PNG_W, VIEW_W, BAND_H

local function layout_pkg()
	view_width, view_height, band_width = VIEW_W, BAND_H, BAND_PNG_W
	ui.visible(pkg, true)
	ui.visible(box, false)
	ui.visible(back, false)
	ui.visible(frame, false)
	ui.size(pkg, view_width, view_height)
	ui.size(band_a, BAND_PNG_W, BAND_PNG_H)
	ui.size(band_b, BAND_PNG_W, BAND_PNG_H)
	ui.size(pkg_waypoint, WAYPOINT_W, WAYPOINT_H)
	ui.size(pkg_caret, CARET_W, CARET_H)
	ui.size(label, view_width, LABEL_H)
	ui.size(distance, view_width, LABEL_H)
	ui.size(distance_shadow, view_width - 1, LABEL_H - 1)
	ui.size(root, view_width, view_height + LABEL_H)
end

local function layout_stock()
	use_pkg = false
	band_width = ui.compass.graphic_width(STOCK.band)
	view_width, view_height = 129, 14
	local box_w, box_h = 137, 22
	if pkg then
		ui.visible(pkg, false)
	end
	ui.visible(box, true)
	ui.visible(back, true)
	ui.visible(frame, true)
	ui.size(box, box_w, box_h)
	ui.size(back, box_w, box_h)
	ui.size(frame, box_w, box_h)
	ui.borders(band, 4, 4, 4, 4)
	ui.graphic_tint(frame, D.color.border)
	ui.size(band, view_width, view_height)
	ui.size(label, box_w, LABEL_H)
	ui.size(distance, view_width, LABEL_H)
	ui.size(distance_shadow, view_width - 1, LABEL_H - 1)
	ui.size(root, box_w, box_h + LABEL_H)
end

local sized = false

local function choose_art()
	-- Package PNGs ship with ndgui-lib (required). Prefer them always.
	if band_a and band_b and pkg_waypoint and pkg_caret and pkg then
		use_pkg = true
		layout_pkg()
	else
		layout_stock()
	end
	sized = true
end

local function metres(d)
	if d >= 1000 then
		return string.format("%.1f km", d / 1000)
	end
	return string.format("%d m", math.floor(d + 0.5))
end

function compass_place(screen_width)
	if not sized then choose_art() end
	D.place_default(placement, root, math.floor(screen_width * 0.5 - view_width / 2), D.TOP_Y)
end

local function apply_pkg(reading)
	local offset = (band_width * (-(reading.heading - math.pi / 2) / turn) - view_width / 2) % band_width
	local left = -math.floor(offset + 0.5)
	local band_top = LINE_Y - math.floor(BAND_PNG_H / 2)
	ui.place(band_a, left, band_top)
	ui.place(band_b, left + band_width, band_top)
	local text = ""
	if reading.has_waypoint and reading.has_position and reading.waypoint_playfield == reading.playfield then
		local dx, dz = reading.waypoint_x - reading.x, reading.waypoint_z - reading.z
		local bearing = math.atan(dz, dx) % turn
		local shift = (reading.heading - bearing) / turn * band_width
		local column = view_width / 2 + shift - math.floor(shift / band_width + 0.5) * band_width
		column = math.max(EDGE, math.min(view_width - EDGE, column))
		ui.visible(pkg_waypoint, true)
		ui.place(pkg_waypoint, math.floor(column - WAYPOINT_W / 2 + 0.5), MARKER_Y - math.floor(WAYPOINT_H / 2))
		text = metres(math.sqrt(dx * dx + dz * dz))
	else
		ui.visible(pkg_waypoint, false)
	end
	ui.place(pkg_caret, math.floor(view_width / 2 - CARET_W / 2 + 0.5), CARET_Y - math.floor(CARET_H / 2))
	ui.text(distance, text)
	ui.text(distance_shadow, text)
end

local function apply_stock(reading)
	if band_width <= 0 then
		return
	end
	local line_y = view_height / 2
	local offset = (band_width * (-(reading.heading - math.pi / 2) / turn) - view_width / 2) % band_width
	ui.compass.offset(band, offset, 0)
	ui.compass.begin(band)
	ui.compass.sprite(band, STOCK.band, band_width / 2, line_y)
	ui.compass.sprite(band, STOCK.band, band_width * 1.5, line_y)
	local text = ""
	if reading.has_waypoint and reading.has_position and reading.waypoint_playfield == reading.playfield then
		local dx, dz = reading.waypoint_x - reading.x, reading.waypoint_z - reading.z
		local bearing = math.atan(dz, dx) % turn
		local shift = (reading.heading - bearing) / turn * band_width
		local column = view_width / 2 + shift - math.floor(shift / band_width + 0.5) * band_width
		ui.compass.sprite(band, STOCK.waypoint, offset + column, line_y)
		text = metres(math.sqrt(dx * dx + dz * dz))
	end
	ui.compass.finish(band)
	ui.text(distance, text)
	ui.text(distance_shadow, text)
end

function compass_apply(reading)
	if not sized then
		choose_art()
	end
	if not reading.has_heading then
		return
	end
	if use_pkg then
		apply_pkg(reading)
	else
		apply_stock(reading)
	end
end
