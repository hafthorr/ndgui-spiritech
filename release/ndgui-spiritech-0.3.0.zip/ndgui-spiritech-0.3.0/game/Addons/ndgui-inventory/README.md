# Scripted item containers

Main Inventory, backpacks, bank and latest corpse/chest loot use one package and
shared `Core.Window`, `Core.Table` and `Grid.cells`. There is no parallel native
Inventory presenter or container list engine.

## Responsibilities

| Owner | Responsibility |
| --- | --- |
| `Inventory/ItemContainer.cs` | GUI-free logical locations, current item/metadata facts, owner/revision/opening checks, captured item identity and native close policy |
| `UI/ItemInputBindings.cs` | Owned hit-view mapping, explicit drop intents, legacy widget bindings, UI eligibility/gesture leases and interaction feedback |
| `UI/ItemInteractionController.cs` | Native pointer/cursor state machine, split/merge/combine/use/equip/offer rules, pending operations and validated transactions |
| Native bag/bank/loot controllers | Server page lifetimes, native identities, bank arrangement, opening/ack/range and distinct closure policies |
| `ScriptedItemContainerWindow` | Package/frame lifecycle, batched fact/resource projection and rendering native interaction feedback |

A canonical read is `ItemLocation.Read()` or `ItemContainer.GetItem(placement)`;
it never returns or searches for a `GuiView`. `CapturedItem` retains the native
item identity and logical epoch. The model is updated independently before
presentation, so native reads and hotbar activation continue without an attached
window, after closing it, or after its package fails/disposes. Ending the native
container/session, not disposing its presentation, invalidates logical locations.
Unapplied native revisions and mismatched character owners still refuse reads.

A pointer hit resolves once through `ItemInputBindings`. Its target contains a
logical location and a separate UI lease. The lease retains widget eligibility,
package/root ownership, view generation and current presentation revision; it
cannot be reused after hiding, mode changes, retirement, failure or replacement.
Sorting/recreating views does not change canonical location identity. Native
interaction facts are published through this seam to Lua and legacy renderers;
no window maintains its own authoritative carry or split state.

Bank locations are real **bank slots**, not cells. The native arrangement maps
visual positions to canonical locations at the input edge. Arrangement changes
invalidate UI bindings immediately without changing canonical bank addresses.
The backend alone rearranges cells or chooses native bank packet addresses.

## Presentation and input

Native options supply positions, title, alignment and offsets. Capacity controls
grid geometry, including the bank's 102 cells and variable bag sizes. Zero slots
retain a minimal closeable frame, not invented destinations. Real empty exact
slots retain a binding with `content = false`. `Table:drop_target(reference)`
binds list open space to an explicit native first-free intent: no game/data
adapter knows the table XML names. Native validation chooses the destination.

Snapshots are batched, not pulled per slot from Lua. Unchanged snapshots skip
projection; canonical reads and warmed input lookups allocate nothing. Icons
remain borrowed native resources. Tooltip/inspection routes resolve the hit view
through the same input seam; their UI-only binding retains an anchor for tooltip
placement, not for canonical item lookup. Wear uses the same native input seam with its own fixed-layout Lua package.
Trade retains its native UI-only shop/tooltip handling.

## Backpack names

Windows configured with `renamable` (bags only) add Rename and Reset To Default to the title-icon menu. Choosing one
publishes `name_request`; the native side prompts for the name and sends `PrkItemRename`. The server keeps the name
on the bag's `pc_items` row and answers with `PrkItemNames`, which it also sends in full on zone-in; the bag window's
title follows the name.

Bank windows show the names of the bags they hold, but a bag in a bank cannot be opened, so it is renamed only while
carried.

## Item search

The main inventory and both banks (character and account) show a search box, with
the watermark "Search", in a bottom panel under their grid, set off by the NPC chat
separator; bags and loot never do. The same panel carries "Slots: used / total" on
the right for windows configured with `slot_count` (inventory, banks and bags; not
loot or overflow). A window reserves the panel's height through `searchable` or
`slot_count` in its configuration, so showing or hiding the search never resizes it.
The package declares its input once (`game.inventory.search_field`); a genuine
native Enter in it sends one `PrkItemSearchRequest` naming the container searched
(`Inventory` or `Bank`), and there is no button. Typing alone sends nothing
(`game.inventory.search_edited` only clears on empty). The server answers with the
slots of that container whose item matches, or that hold a bag containing a match,
echoing the container so each window takes only its own results; each slot
description carries `search` = `match`, `other` or empty. Matches draw the
selection frame as an overlay, so real selection is untouched; the rest fade.
Open bags take the inventory's search too: `BagWindows` matches their contents
locally with the same `ItemNameQuery` the server uses.
`ItemSearchSession` owns each window's search: closing or reopening the bank drops
it, and a content change while a search is shown asks the server again, so moved
items never keep stale marks.

## Closure and preferences

- Bag/loot close buttons and native Escape routing request server closure.
  Typed close references require native activation plus current logical owner,
  epoch/version and native UI eligibility. Observers cannot manufacture a request.
- Title-menu **Close Window** hides bag/loot locally without a server toggle.
  An unchanged open page does not reopen a locally hidden window.
- Bank retains `ServerDrivenWindow`: local close/session hiding invoke the native
  callback; server-driven closure does not echo it. No new Escape preference is
  imposed. Fresh contents reanchor range and discard older expected deposit cells.
- Corpse range removal drops its native page without toggling it open again;
  chest range closure requests a close once while awaiting the server.
- Bag instances share `bag_window` preference storage, but retain independent live
  presentation and native identities. Other preference identities and main
  placement/open/pin/Escape persistence remain unchanged.
- Package failure disables UI bindings, not the native model. A validated native
  close fallback remains available; old failed/replaced roots cannot close a new
  container. Native item transaction rules and refusal messages remain authoritative.

Tests exercise GUI-free logical reads/empty destinations, canonical bank slots,
real native input, widget recreation and cross-package captures, hotbars after
Inventory presentation disposal, all container policies, resource cleanup and
allocation gating. Installed-art/live sessions, Windows/macOS, new CI and combined
full-client Native AOT remain separate checks; shared AOT alone does not establish
full-client adapter or installed rendering acceptance.
