# Skills

Lua owns the expanded/compact layouts, categories, selection, row/detail/suggestion
presentation, colors and confirmation rendering. The top-left **I** menu has a
checked **Compact View** toggle for switching both ways; no footer mode buttons
remain. The mode option is hidden while a native confirmation is active. The package composes
`Core.Window` and package-local XML. It does not calculate IP costs, caps,
trickle previews or suggestion allocation.

`SkillEditingSession` owns one native `SkillDraft` and reconciles current stats,
inventory and `ClientSkillRequests`. Native code sends batched metadata, preview
values, availability/refusal facts and operation references. Unchanged frames
bypass projection without managed allocation. Unknown values stay explicit.

## Local edits versus submission

`game.skills.propose(reference, target)` stages a target **purchased/base value**.
It works from buttons, native slider observers or text edits. The native session
validates the current skill/character, integral value, saved lower bound, cost,
cap, budget and editing eligibility. Refusal leaves purchases unchanged.

`affordable_maximum` and `saved_value` supply native targets for Shift editing.
`suggest` (Auto-distribute IP) stages the IP priorities in canonical order,
independent of Lua row order: the installed `ipdist.xml` table, overlaid by the
player's own choices. None of these capabilities sends a packet.

## IP priorities

**Set IP priorities** opens a native priority edit: `edit_priorities`, then
`set_priority(reference, priority)` with 1-4, 0 for none, or the skill's
`default_priority`. Lua swaps each row's value, -/+ and bar for the picker and
the footer for Save Priorities / Cancel. Lua names the values Max (1),
High (2), Medium (3), Low (4) and None (0). `save_priorities` keeps only the choices
that differ from the table, per profession, in the machine preference
`ip_priorities`; the install file is never written. Hiding the window, entering
compact view or a profession change discards an unsaved priority edit. While it
is open, IP editing and resets are refused.

`save` requires a genuine activation matching the exact represented draft.
`prepare_reset` and `confirm` require separate matching activations. Resetting
saved IP is not a low draft target. Confirmation references identify a single
native question and are revoked by authoritative state changes, replacement,
hiding or teardown. Native validation runs again when consuming them. Text,
slider, repeat, projection and other observer callbacks cannot submit/reset.

The built-in UI retains +/- buttons, native held repeats and one-shot Shift
behavior. It does not add a slider or input field; regression tests load alternate
editors against the same production draft capability. Skills remains fully editable
during combat, including categories, compact mode, suggestions, resets and discard
questions. This native component opts out of combat layout lockdown, not physical
activation or draft/session validation.

## Lifecycle

All ordinary close routes go through native `CanClose`. Unsaved changes require
a discard-close question; cancelling keeps the draft. Forced session hiding
revokes local edits/questions without blocking logout. Script failure releases
owned input and local draft state, preserves pending native requests and allows
the diagnostic to close. There is no fallback C# Skills presenter.

The native Impact grouping consumer still uses `Layouts/SkillsCategories.xml`;
graphics tests still use `Layouts/SkillRow.xml`. Those shared assets remain, but
Skills no longer uses the legacy layout route.
