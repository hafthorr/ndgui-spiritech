# Wear

Lua composes `Core.Window`, switches the four equipment tabs and presents the
native equipment snapshot through `Grid.cells` with fixed XML views. The slot
labels, weapon order and implant gaps stay in `content.xml`; Lua does not sort or
reparent the slots. Empty equipment locations retain exact native drop targets.

`ScriptedWearWindow` supplies batched item references, borrowed icons, stack and
ammo counts, lock countdowns and over-equipment facts. Ammo-only changes refresh
the snapshot; unchanged updates bypass Lua without managed allocation. Solar
weapons do not project rounds. Lua selects stack fallback, fading and tint.

Equipment identity, carry/selection state, pointer leases, equip/unequip rules
and transactions remain native through `ItemContainer`, `ItemInputBindings` and
`ItemInteractionController`. Wear adds no game-command exports. Native tooltip
and inspection services resolve semantic slot bindings, not Lua text. Tab and
visibility changes invalidate old gestures and release this window's tooltip.
Wear does not participate in combat layout lockdown: tabs, selection and slot
presentation stay live in combat, and equipping remains subject to the native
item rules.

The frame retains the existing Wear identity, fixed size, initial placement,
pin/open/placement persistence and Escape preference. Failure uses the shared
Lua diagnostic and disables presentation input without disposing equipment data
or restoring a C# presenter.
